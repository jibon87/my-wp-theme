(function ($) {
    "use strict";

    //  ======= Default js =======  //
    new WOW().init();

    //  ======= PreLoader =======  //
    $(".ab-progress").progressBar();

    //  ======= counterUp =======  //
    $(".counter").counterUp({
        delay: 10,
        time: 700
    });

    //  ======= isotope =======  //
    var $grid = $(".isotope").isotope({
        itemSelector: ".grid-item",
        percentPosition: true,
        masonry: {
            columnWidth: 1
        }
    });
    // filter items on button click
    $(".filter-button-group").on("click", "button", function () {
        var filterValue = $(this).attr("data-filter");
        $grid.isotope({ filter: filterValue });
    });
    //isotope-active class
    $(".filter-button-group button").on("click", function () {
        $(".filter-button-group button.isotope-active").removeClass("isotope-active");
        $(this).addClass("isotope-active");
    });

    //  ======= swiper slider =======  //
    var swiper = new Swiper(".mySwiper", {
        slidesPerView: 1,
        loop: true,
        autoplay: {
            delay: 2000,
            disableOnInteraction: false
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev"
        },
        scrollbar: {
            el: ".swiper-scrollbar",
            draggable: true
        }
    });

    //  ======= one page nav =======  //
    $(".scroll").onePgaeNav({
        wrapper: ".onepage-nav",
        activeClass: "active",
        speed: 10
    });

    //  ======= headroom =======  //
    var header = document.querySelector(".header");
    var headroom = new Headroom(header, {
        tolerance: {
            down: 10,
            up: 20
        },
        offset: 15
    });
    headroom.init();

    //  ======= mobile menu =======  //
    $(".btn").on("click", function () {
        $(this).toggleClass("click");
        $(".sidebar").toggleClass("show");
    });
    //mobile-menu active class
    $(".sidebar ul li").on("click", function () {
        $(this).addClass("mobile-menu-active").siblings().removeClass("mobile-menu-active");
    });

   

})(jQuery);
